package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;


public class Database extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "database.db";
    private static final int VERSION = 1;

    // Data table to hold login credentials.
    public static final class LoginTable {
        private static final String TABLE = "logins";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "Username";
        private static final String COL_PASSWORD = "Password";
    }

    // Data table to hold inventory item info.
    public static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_ITEM_NAME = "Item";
        private static final String COL_QUANTITY = "Quantity";
    }

    // Data table to hold text alert phone number info.
    public static final class PhoneTable {
        private static final String TABLE = "textAlertNumber";
        private static final String COL_ID = "_id";
        private static final String COL_PHONE_NUMBER = "PhoneNumber";
    }

    public Database(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create login table.
        String loginTableStatement = "CREATE TABLE " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                LoginTable.COL_USERNAME + " TEXT, " +
                LoginTable.COL_PASSWORD + " TEXT)";

        db.execSQL(loginTableStatement);

        // Create inventory table.
        String inventoryTableStatement = "CREATE TABLE " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                InventoryTable.COL_ITEM_NAME + " TEXT, " +
                InventoryTable.COL_QUANTITY + " INTEGER)";

        db.execSQL(inventoryTableStatement);

        // Create text alert phone number table.
        String PhoneTableStatement = "CREATE TABLE " + PhoneTable.TABLE + " (" +
                PhoneTable.COL_ID + " INTEGER," +
                PhoneTable.COL_PHONE_NUMBER + " TEXT )";

        db.execSQL(PhoneTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    // Method for creating user in database
    public boolean createLogin(String username, String password) {

        // Check to see if username already exists
        if (checkExistingCredentials(username)) {
            return false;
        }
        else { // Otherwise, create new account.
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put(LoginTable.COL_USERNAME, username);
            values.put(LoginTable.COL_PASSWORD, password);

            // Insert new login into database and return true if successful.
            long insert = db.insert(LoginTable.TABLE, null, values);
            if (insert == 1) {
                return true;
            }
            else {
                return false;
            }
        }
    }

    // Checks username and password before giving the ok to log user in.
    public boolean getCredentials(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        // String to hold data query.
        String sql = "SELECT * FROM " + LoginTable.TABLE + " where Username = ?";
        // Puts a cursor on the data query.
        Cursor cursor = db.rawQuery(sql, new String[] { username });
        //Iterate through the database to find if login exists.
        if (cursor.moveToFirst()) {
            do {
                String dbPassword = cursor.getString(2);

                if (password.equals(dbPassword)) {
                    cursor.close();
                    return true;
                }

                } while (cursor.moveToNext());
        }
        cursor.close();

        //Return false if password is invalid or login doesn't exist.
        return false;
    }

    // Method that checks to see if a username is already taken.
    public boolean checkExistingCredentials(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT * FROM " + LoginTable.TABLE + " where Username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { username });
        if (cursor.moveToFirst()) {
            do {
                String dbUsername = cursor.getString(1);

                if (username.equals(dbUsername)) {
                    cursor.close();
                    return true;
                }

            } while (cursor.moveToNext());
        }
        cursor.close();
        return false;
    }

    // Adds item to Inventory Database.
    public long addItem(String name, int quantity) {
        // Gets the database to write to.
        SQLiteDatabase db = this.getWritableDatabase();

        // Variable for holding the content values of the table.
        ContentValues values = new ContentValues();

        // Assigns the table values the new data.
        values.put(InventoryTable.COL_ITEM_NAME, name);
        values.put(InventoryTable.COL_QUANTITY, quantity);

        // Inserts the new data into the table
        long insert = db.insert(InventoryTable.TABLE, null, values);
        return insert;
    }

    // Method for getting the inventory list from the database.
    public ArrayList<ItemInfo> retrieveInventory() {

        ArrayList<ItemInfo> inventoryList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT * FROM " + InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {

                int itemId = cursor.getInt(0);
                String itemName = cursor.getString(1);
                int itemQuantity = cursor.getInt(2);

                ItemInfo newItem = new ItemInfo(itemId, itemName, itemQuantity);

                inventoryList.add(newItem);

            } while (cursor.moveToNext());
        }
        cursor.close();
        return inventoryList;
    }

    // Deletes an item from inventory.
    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " = ?",
                new String[] { Integer.toString(id) });

        return rowsDeleted > 0;
    }

    // Updates an item from inventory.
    public boolean updateItem(int id, int qty) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_QUANTITY, qty);

        int rowsUpdated = db.update(InventoryTable.TABLE, values, InventoryTable.COL_ID + " = ?",
                new String[] { Integer.toString(id) });

        return rowsUpdated > 0;
    }

    // Method for looking up the number that is set up for text alerts.
    public String lookUpTextNumber() {

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "SELECT * FROM " + PhoneTable.TABLE + " where _id = ?";

        Cursor cursor = db.rawQuery(sql, new String[] { "1" });

        if (cursor.moveToFirst()) {
            String dbPhoneNumber = cursor.getString(1);
            return dbPhoneNumber;
        }
        else {
            return "";
        }
    }

    // Method for assigning a phone number to be signed up for text alerts.
    public long assignTextNumber (String textNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(PhoneTable.COL_ID, 1);
        values.put(PhoneTable.COL_PHONE_NUMBER, textNumber);

        long insert = db.insert(PhoneTable.TABLE, null, values);
        return insert;

    }

}
