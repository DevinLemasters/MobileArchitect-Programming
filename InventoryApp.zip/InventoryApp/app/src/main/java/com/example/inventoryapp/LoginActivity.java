package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        try{
            db = new Database(getApplicationContext());
        }
        catch (Exception e) {
            Toast.makeText(this, "OnCreate", Toast.LENGTH_SHORT).show();
        }

    }

    // Method for creating a new user into the login database.
    public void createUser(View view) {
        TextView usernameValue = findViewById(R.id.editTextTextEmailAddress);
        TextView passwordValue = findViewById(R.id.editTextTextPassword);
        String username = usernameValue.getText().toString();
        String password = passwordValue.getText().toString();

        try{
            boolean isWorking = db.createLogin(username, password);
            Toast.makeText(this, String.valueOf(isWorking), Toast.LENGTH_SHORT).show();
        }
        catch (Exception e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
    }

    // Method for logging the user into their account.
    public void login(View view) {
        TextView usernameValue = findViewById(R.id.editTextTextEmailAddress);
        TextView passwordValue = findViewById(R.id.editTextTextPassword);
        String username = usernameValue.getText().toString();
        String password = passwordValue.getText().toString();

        boolean loginSuccess = db.getCredentials(username, password);

        if (loginSuccess) {
            Intent intent = new Intent(this, ViewInventory.class);
            startActivity(intent);
        }
        else {
            Toast.makeText(this, "Invalid Credentials!", Toast.LENGTH_SHORT).show();
        }

    }


}