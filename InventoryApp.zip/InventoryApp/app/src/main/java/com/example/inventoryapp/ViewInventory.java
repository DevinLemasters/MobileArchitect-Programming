package com.example.inventoryapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewInventory extends AppCompatActivity {

    ListView gridView;
    Database db;
    private String m_Text = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_inventory);

        db = new Database(getApplicationContext()); // Get the database.

        getInventory();
    }

    //Method for retrieving the inventory from the database.
    public void getInventory() {
        gridView = (ListView) findViewById(R.id.gridView);

        // Gets the inventory data from the database.
        ArrayList<ItemInfo> inventoryList = db.retrieveInventory();

        ArrayList<String> textFormatList = new ArrayList<>();

        // Creates String ArrayList that gets information from the ItemInfo ArrayList and displays it in a proper format to the user.
        for (int i = 0; i < inventoryList.size(); i++) {
            String displayString = "   ID: " + inventoryList.get(i).id + "             Item: " + inventoryList.get(i).name + "             Qty: " + inventoryList.get(i).quantity;

            textFormatList.add(displayString);
        }

        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, textFormatList);


        // Gives the inventory data to listView to display data on screen.
        gridView.setAdapter(arrayAdapter);
    }


    // Opens activity for adding items.
    public void addItem(View view) {

        Intent intent = new Intent(this, AddInventory.class);
        startActivity(intent);
    }

    // Opens activity for deleting items.
    public void deleteItem(View view) {

        Intent intent = new Intent(this, DeleteInventory.class);
        startActivity(intent);
    }

    // Opens activity for updating items.
    public void updateItem(View view) {
        Intent intent = new Intent(this, UpdateInventory.class);
        startActivity(intent);
    }

    // Prompts the user if they would like to enable the SMS feature of the app and asks for a phone number.
    public void smsEnable(View view) {
        String smsPermission = Manifest.permission.SEND_SMS;

        // Request access to sending SMS messages.
        ActivityCompat.requestPermissions(this, new String[] { smsPermission }, 0);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Phone Number to Receive Text Alerts (Texting yourself):");

        // Set up the input
        final EditText input = new EditText(this);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                m_Text = input.getText().toString();

                if (db.assignTextNumber(m_Text) == 1) {
                    Toast.makeText(ViewInventory.this, "Number Updated Successfully!", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(ViewInventory.this, "Error, number not updated!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();

    }

}