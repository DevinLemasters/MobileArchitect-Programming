package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateInventory extends AppCompatActivity {

    // Variable for holding the SQLite database.
    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_inventory);

        // Gets data from database.
        db = new Database(getApplicationContext());
    }



    // Method for updating the inventory.
    public void updateInventory(View view) {

        // Gets information from user input, ID and QTY.
        EditText editId = (EditText) findViewById(R.id.editId);
        EditText editQty = (EditText) findViewById(R.id.editQty);

        // Converts EditText to String.
        int updateId = Integer.parseInt(editId.getText().toString());
        int updateQty = Integer.parseInt(editQty.getText().toString());


        // Updates item in database.
        db.updateItem(updateId, updateQty);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                if (updateQty < 2) {
                    lowInventorySms();
                }
            }
        }

        // Returns to ViewInventory activity.
        Intent intent = new Intent(this, ViewInventory.class);
        startActivity(intent);

    }

    // Sends and SMS message when running low or depleted inventory.
    public void lowInventorySms() {
        SmsManager mySmsManager = SmsManager.getDefault();
        mySmsManager.sendTextMessage(db.lookUpTextNumber(), null, "An item in your inventory is either low or depleted!", null, null);
    }

}