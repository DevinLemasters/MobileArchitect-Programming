package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddInventory extends AppCompatActivity {

    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_inventory);

        db = new Database(getApplicationContext());
    }


    // Method for adding an item into inventory.
    public void addItem(View view) {

        EditText itemName = (EditText) findViewById(R.id.itemName);
        EditText itemQty = (EditText) findViewById(R.id.itemQty);

        String item = itemName.getText().toString();
        int qty = Integer.parseInt(itemQty.getText().toString());

        db.addItem(item, qty);

        Intent intent = new Intent(this, ViewInventory.class);
        startActivity(intent);
    }
}