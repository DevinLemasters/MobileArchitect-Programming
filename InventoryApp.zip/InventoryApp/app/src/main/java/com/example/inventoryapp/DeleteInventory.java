package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class DeleteInventory extends AppCompatActivity {

    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_inventory);

        db = new Database(getApplicationContext());
    }

    // Deletes an item from inventory.
    public void deleteItem(View view) {

        EditText idToDelete = (EditText) findViewById(R.id.deleteQty);
        db.deleteItem(Integer.parseInt(idToDelete.getText().toString()));

        Intent intent = new Intent(this, ViewInventory.class);
        startActivity(intent);
    }


}