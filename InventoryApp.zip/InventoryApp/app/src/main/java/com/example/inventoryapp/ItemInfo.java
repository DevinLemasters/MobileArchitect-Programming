package com.example.inventoryapp;

// A class for holding the information contained in each item entry.

public class ItemInfo {

    public int id;
    public String name;
    public int quantity;

    public ItemInfo(int id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

}
